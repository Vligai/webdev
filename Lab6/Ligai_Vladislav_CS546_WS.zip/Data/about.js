/*Vladislav Ligai*/
about = {
  name: "Charlie",
  biography: "Charlie is a simple man with the best taste in everything. Part-Time Survey taker and a professional Farmville player. Born and raised in Alpine Tundra, Charlie was looked after by native mountain goats. He doesn't rememmber anything from his younger years, in fact, his oldest memory was from when he was 14 years old and he was strating High School. After successfully getting his degree in Culinary Arts he moved to solitery island to master his craft..",
  favoriteShows: ["Popcultured", "Cop Rock", "Jerry Springer Show", "My Mother the Car", "Allen Gregory","The Secret Diary of Desmond Pfeiffer","The P.T.L. Club","Holmes and Yo-Yo"],
  hobbies: ["Drinking", "Farmville", "Taking surveys","Sleeping","Planking","Playing dead","Tumblr activism"]
};
module.exports = about;