/*
Vladislav Ligai
*/
const loginRoutes = require("./login");

module.exports = loginRoutes;