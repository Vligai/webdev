/*Vladislav Ligai*/
const my_education = require("./education");
const my_story = require("./story");
const about_me = require("./about");

module.exports = {
    education : my_education,
    story : my_story,
	about : about_me
};