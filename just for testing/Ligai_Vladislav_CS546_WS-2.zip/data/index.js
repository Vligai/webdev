/*Vladislav Ligai*/
const recipesData = require("./recipes");
const commentsData = require("./comments");
module.exports = {
    recipes: recipesData,
    comments: commentsData
};