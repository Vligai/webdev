/*Vladislav Ligai*/

education = [
    {
      schoolName: "GoodEnough College",
      degree: "B.S. in Culinary Arts",
      favoriteClass: "Intermediate Breathing",
      favoriteMemory: "learning how to breathe"
    },
    {
      schoolName: "Krap Highschool",
      degree: "Highschool Diploma",
      favoriteClass: "sugar tasting",
      favoriteMemory: "doing math"
    },
	{
      schoolName: "Baume Levres Highschool",
      degree: "Dropped out",
      favoriteClass: "hoop jumping",
      favoriteMemory: "dropping out"
    }
];
module.exports = education;